class AppConst {
  static const String appCurrency = "SYP";
  static const double fee = 1000;
  static const String url = "https://www.webberkn.com/nourmarket";
}
